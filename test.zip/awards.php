<?php

//echo $_COOKIE['prcode'];
//echo $_GET['dbtable'];
include 'dbconnect.php';

if (!empty($_COOKIE['prcode'])) {
    $prcode = $_COOKIE['prcode'];
    $conn = dbconnect();
    $sql = "SELECT a.FK_rootTag FROM programelement pe ,award a WHERE pe.FK_award = a.FK_rootTag and pe.code = '" . $prcode . "'";
    $result = $conn->query($sql);
    $rowcount = mysqli_num_rows($result);
    if ($rowcount > 0) {
        echo "Award count : " . $rowcount;
    }
    $conn->close();
}
?>